# Top Speed Appliance Website

A responsive, fast, and modern **React + Vite** website for **Top Speed Appliance**, designed with the business brand colors **red, black, and white**. This repository contains the full source code, build configuration, and deployment instructions.

---

## 🚀 Tech Stack
- **React** (Frontend UI)
- **Vite** (Build tool + Dev server)
- **TailwindCSS** (Styling)
- **JavaScript / JSX**
- **Vercel** (Deployment platform)

---

## 📁 Project Structure
```
root/
├── src/
│   ├── components/
│   ├── pages/
│   ├── assets/
│   ├── App.jsx
│   └── main.jsx
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

---

## 🛠️ Installation
### 1. Clone the repository
```bash
git clone https://github.com/YOUR-USERNAME/top-speed-appliance.git
cd top-speed-appliance
```

### 2. Install dependencies
```bash
npm install
```

### 3. Run the development server
```bash
npm run dev
```
This will open your project at:
```
http://localhost:5173/
```

---

## 📦 Build for Production
To create the `dist` build folder:
```bash
npm run build
```
The `dist/` folder will be created automatically.

---

## 🌐 Deployment (Vercel)
1. Push your code to GitHub.
2. Go to **https://vercel.com**.
3. Import your repository.
4. Vercel auto-detects **Vite** and builds automatically.
5. Connect your custom domain: **topspeedappliance.com**.

---

## 🎨 Features
- ⚡ Super-fast Vite engine
- 📱 Fully responsive mobile-first design
- 🟥⬛⬜ Red/Black/White brand styling
- ✔ Custom service pages
- 🔧 Clean component architecture
- 🔍 SEO-ready structure
- 🌩 Deployment optimized for Vercel

---

## 🖼 Screenshots (optional placeholders)
_Add your website images here_

---

## 📬 Contact
**Top Speed Appliance**

Business website built for professional appliance repair services.

---
